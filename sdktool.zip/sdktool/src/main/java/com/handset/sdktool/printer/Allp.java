package com.handset.sdktool.printer;

/**
 * @ClassName: Allp
 * @author: wr
 * @date: 2022/11/23 10:22
 * @Description:作用描述
 */
public class Allp {
}
