package com.handset.sdktool.util;

import android.content.Context;
import android.util.Log;

import com.handset.sdktool.printer.sunmi.SunmiPrintHelper;

public class Device {

    public static String SUNMI = "SUNMI";//商米
    public static String HM = "HM";//汉印
    public static String NF = "NF";//NF
    public static String ZEBAR = "ZEBAR";//ZEBAR
}
