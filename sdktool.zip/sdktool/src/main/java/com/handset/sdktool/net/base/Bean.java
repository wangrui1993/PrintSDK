package com.handset.sdktool.net.base;

/**
 * @ClassName: Bean
 * @author: wr
 * @date: 2022/11/4 15:44
 * @Description:作用描述
 */
public class Bean {
}
