package com.handset.sdktool;

/**
 * @ClassName: Config
 * @author: wr
 * @date: 2022/11/16 11:06
 * @Description:作用描述
 */
public class Config {
    public final static String RELATIONSHIPMAPDATA = "RELATIONSHIPMAPDATA";
    public final static String RELATIONSHIPPP = "RELATIONSHIPPP";
}
