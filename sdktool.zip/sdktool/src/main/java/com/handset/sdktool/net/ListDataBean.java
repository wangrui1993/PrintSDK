package com.handset.sdktool.net;

import java.util.List;

public class ListDataBean<T> {
    private List<T> list;

    public List<T> getList() {
        return list;
    }

    public void setList(List<T> list) {
        this.list = list;
    }
}
